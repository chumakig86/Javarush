package com.javarush.task.task29.task2909.human;

/**
 * Created by chumak on 10.07.17.
 */
public class test {
    public static void main(String[] args) {

    }
}
