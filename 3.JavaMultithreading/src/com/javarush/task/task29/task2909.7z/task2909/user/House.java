package com.javarush.task.task29.task2909.user;

public class House {
    public String house;
}